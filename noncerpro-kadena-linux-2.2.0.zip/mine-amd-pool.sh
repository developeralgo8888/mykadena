#!/bin/bash

./noncerpro --address=ac3a4dac6a15c48b854186e615a35ed90e747f9fa6b593712b964862e2855490  --platform amd --mode pool --server stratum+tcp://kda-us-east.ss.poolflare.net:443 -i 28 -t 2


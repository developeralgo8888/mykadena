#!/usr/bin/env bash

#######################
# Functions
#######################


get_cards_hashes(){
        # hs is global
        hs=''
        for (( i=0; i < ${GPU_COUNT_AMD}; i++ )); do
                local MHS=`cat $LOG_NAME | grep "GPU#$(echo $i) " | tail -n 1 | awk '{ printf $5"\n" }'`
                hs[$i]=`echo $MHS`
		for (( i=0; i < ${GPU_COUNT_NVIDIA}; i++ )); do
                local MHS=`cat $LOG_NAME | grep "GPU#$(echo $i) " | tail -n 1 | awk '{ printf $5"\n" }'`
                hs[$i]=`echo $MHS`
        done
}

get_nvidia_cards_temp(){
        echo $(jq -c "[.temp$nvidia_indexes_array]" <<< $gpu_stats)
}

get_amd_cards_temp(){
        echo $(jq -c "[.temp$amd_indexes_array]" <<< $gpu_stats)
}

get_nvidia_cards_fan(){
        echo $(jq -c "[.fan$nvidia_indexes_array]" <<< $gpu_stats)
}

get_amd_cards_fan(){
		echo $(jq -c "[.fan$amd_indexes_array]" <<< $gpu_stats)
}

get_miner_uptime(){
        local duration=$(ps -o etimes= -C "$CUSTOM_NAME")
        echo $duration
}

get_total_hashes(){
        local unit=`cat ${LOG_NAME} | grep "Total Hashrate: " | tail -n 1 | awk '{ printf $7"\n" }'`
        local Total=`cat ${LOG_NAME} | grep "Total Hashrate: " | tail -n 1 | awk '{ printf $6"\n" }'`

        if [ "$unit" == "MH/s" ]; then
                echo $Total | awk '{ printf($1*1000) }'
        else
                echo $Total
        fi
}

get_log_time_diff(){
        local getLastLogTime=`tail -n 100 ${LOG_NAME} | grep "NoncerPro: " | tail -n 1 | awk '{ printf $2"\n" }' | cut -d "]" -f1`
        local logEpoch=`date --date="$getLastLogTime" +%s`
        local curHour=`date +"%H:%M:%S"`
        local curEpoch=`date --date="$curHour" +%s`
        [ "$curEpoch" -lt "$logEpoch" ] && let curEpoch+=86400
        echo `expr $curEpoch - $logEpoch`
}

#######################
# MAIN script body
#######################

. /hive/miners/custom/$CUSTOM_MINER/h-manifest.conf
LOG_NAME="$CUSTOM_LOG_BASENAME.log"

[[ -z $GPU_COUNT_NVIDIA ]] &&
        GPU_COUNT_NVIDIA=`gpu-detect NVIDIA`

[[ -z $GPU_COUNT_AMD ]] &&
        GPU_COUNT_AMD=`gpu-detect AMD`


# Calc log freshness
diffTime=$(get_log_time_diff)
maxDelay=120

# echo $diffTime

# If log is fresh the calc miner stats or set to null if not
if [ "$diffTime" -lt "$maxDelay" ]; then
        hs=
        get_cards_hashes                        # hashes array
        hs_units='khs'                          # hashes units
        uptime=$(get_miner_uptime)              # miner uptime
        temp=$(get_nvidia_cards_temp) &&  $(get_amd_cards_temp)            # cards temp
        fan=$(get_nvidia_cards_fan) &&  $(get_amd_cards_fan)               # cards fan
        algo="kadena"                      # algo

        # make JSON
        stats=$(jq -nc \
                        --argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
                        --arg hs_units "$hs_units" \
                        --argjson temp "$temp" \
                        --argjson fan "$fan" \
                        --arg uptime "$uptime" \
                        --arg algo "$algo" \
                        '{$hs, $hs_units, $temp, $fan, $uptime, $algo}')


        # total hashrate in khs
        khs=$(get_total_hashes)



else
        stats=""
        khs=0
fi

# debug output
#echo stats: $stats
#echo khs:   $khs
